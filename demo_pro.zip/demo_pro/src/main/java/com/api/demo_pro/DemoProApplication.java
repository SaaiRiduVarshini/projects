package com.api.demo_pro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProApplication.class, args);
	}

}
