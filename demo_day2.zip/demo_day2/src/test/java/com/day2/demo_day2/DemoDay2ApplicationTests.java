package com.day2.demo_day2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDay2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
